<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>ECO : Tap, speak and get rewarded.</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="description" content="">
<meta name="author" content="">

<!-- styles -->
<link href="../css/bootstrap.css" rel="stylesheet">
<style>
body {
	padding-top: 90px;
}
</style>

<link href="http://geteco.com/css/bootstrap-responsive.css" rel="stylesheet">
<link href="http://geteco.com/css/fonts.css" rel="stylesheet">
<!--[if lt IE 9]>
      <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
<![endif]-->

<!--fav and touch icons -->
<link rel="shortcut icon" href="http://geteco.com/img/favicon.ico">
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
<script type="text/javascript" src="http://geteco.com/js/feature_carousel.js"></script>
<script type="text/javascript" src="http://geteco.com/js/common.js"></script>


<script type="text/javascript">
$(document).ready(function(){
	slider();
});
</script>
</head>

<body>
<div class="navbar navbar-fixed-top">
  <div class="navbar-inner">
    <div class="container"><a class="brand" href="http://geteco.com/index.html"><img src="http://geteco.com/img/logo.png" alt="ECO"><span id="pulse"></span></a><a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse"> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </a>
      <div class="nav-collapse">
        <ul class="nav">
          <li><a href="http://geteco.com/index.html">Home</a></li>
          <li><a href="http://geteco.com/how-it-works.html">How it works</a></li>
          <li><a href="http://geteco.com/merchants.html">Merchants</a></li>
          <li><a href="http://geteco.com/pricing.html">Pricing</a></li>
          <li><a href="http://geteco.com/support/">Support</a></li>
          <li class="login"><a href="http://www.geteco.com/login">login</a></li>
        </ul>
      </div>
      <!--/.nav-collapse --> 
    </div>
  </div>
</div>

<div class="bg notFound">
  <div class="container">
    <div class="row ">
      
      <h1>404</h1>
      <h2>File Not Found</h2>
      <p>The page you are looking for might have been removed, 
had its name changed, or is temporarily unavailable.</p>
      
    </div>
</div>
</div>
<div class="footer">
  <div class="container">
    <div class="row">
      <div class="span3">
        <h2> Main Menu</h2>
        <ul>
          <li><a href="http://geteco.com/index.html">Home</a></li>
          <li><a href="http://geteco.com/how-it-works.html">How this works</a></li>
          <li><a href="http://geteco.com/merchants.html">Merchants</a></li>
          <!--<li><a href="#">Blog</a></li>-->
          <li><a href="http://geteco.com/about-us.html">About us</a></li>
          <li><a href="http://geteco.com/contact.html">Contact us</a></li>
        </ul>
      </div>
      <div class="span3">
        <h2>Other</h2>
        <ul>
          <li><a href="http://geteco.com/faq.html">FAQ's</a></li>
          <!--<li><a href="#">Recommendations</a></li>-->
          <li><a href="http://geteco.com/terms.html">Terms of Service</a></li>
          <li><a href="http://geteco.com/privacy.html">Privacy Policy</a></li>
          <li><a href="http://geteco.com/join-our-newsletter.html">Join our news letter</a></li>
        </ul>
      </div>
      <div class="span3">
        <h2>Connect with us</h2>
        <ul class="social">
          <li><a href="https://twitter.com/EcoConsumerServ"><img src="http://geteco.com/img/t.png"><b>Follow us</b> on twitter</a></li>
          <li><a href="https://www.facebook.com/pages/Eco/440592189312978"><img src="http://geteco.com/img/f.png"><b>Become a fan</b> on facebook</a></li>
          <!--<li><a href="#"><img src="img/s.png"><b>Subscribe</b> to our blog</a></li>-->
        </ul>
      </div>
      <div class="span4"> &nbsp; </div>
      <div class="span9 border">&copy; Copyright 2002-2012 <a href="http://geteco.com"><b>ECO</b></a>, All rights reserved. Handcrafted by <a href="http://woofwebstudio.com"><b>woof</b></a></div>
    </div>
  </div>
</div>

<!-- /container --> 
<!-- javascript --> 
<script src="http://geteco.com/js/bootstrap-transition.js"></script> 
<script src="http://geteco.com/js/bootstrap-tooltip.js"></script> 
<script src="http://geteco.com/js/bootstrap-popover.js"></script> 
<script src="http://geteco.com/js/bootstrap-button.js"></script> 
<script src="http://geteco.com/js/bootstrap-collapse.js"></script> 
<script src="http://geteco.com/js/bootstrap-carousel.js"></script> 
<script src="http://geteco.com/js/bootstrap-typeahead.js"></script>
</body>
</html>
