//$("#banner").backstretch('images/main/bg.jpg');
	$("#customer").backstretch('images/main/customer.jpg');
	$("#customer").backstretch('images/main/customer.jpg');
	$('#myTab a').click(function (e) {
	e.preventDefault()
	$(this).tab('show')
})

$('#mobile').popover({
    html: true,
    trigger: 'hover',
    container: '#mobile',
    placement: 'bottom',
    content: function () {
        return '<i class="icon-mobile-phone"></i><div class="info"><h2>移动应用</h2><p>您可以在移动设备上通过App或者浏览器控制设备</p></div>';
    },
    animation: false
	}).on({
    show: function (e) {
        var $this = $(this);
        // Currently hovering popover
        $this.data("hoveringPopover", true);
        // If it's still waiting to determine if it can be hovered, don't allow other handlers
        if ($this.data("waitingForPopoverTO")) {
            e.stopImmediatePropagation();
        }
    },
    hide: function (e) {
        var $this = $(this);
        // If timeout was reached, allow hide to occur
        if ($this.data("forceHidePopover")) {
            $this.data("forceHidePopover", false);
            return true;
        }
        // Prevent other `hide` handlers from executing
        e.stopImmediatePropagation();
        // Reset timeout checker
        clearTimeout($this.data("popoverTO"));
        // No longer hovering popover
        $this.data("hoveringPopover", false);
        // Flag for `show` event
        $this.data("waitingForPopoverTO", true);
        // In 1500ms, check to see if the popover is still not being hovered
        $this.data("popoverTO", setTimeout(function () {
            // If not being hovered, force the hide
            if (!$this.data("hoveringPopover")) {
                $this.data("forceHidePopover", true);
                $this.data("waitingForPopoverTO", false);
                $this.popover("hide");
            }
        }, 1500));
        // Stop default behavior
        return false;
    }
	}).on({
    show: function () {
        console.log("shown");
    },
    hide: function () {
        console.log("hidden");
    }
});


$('#sms').popover({
    html: true,
    trigger: 'hover',
    container: '#sms',
    placement: 'bottom',
    content: function () {
        return '<i class="icon-comments"></i><div class="info"><h2>短信服务</h2><p>手机短信是与设备交互的重要方式，您可以通过手机短信控制设备</p></div>';
    },
    animation: false
	}).on({
    show: function (e) {
        var $this = $(this);
        // Currently hovering popover
        $this.data("hoveringPopover", true);
        // If it's still waiting to determine if it can be hovered, don't allow other handlers
        if ($this.data("waitingForPopoverTO")) {
            e.stopImmediatePropagation();
        }
    },
    hide: function (e) {
        var $this = $(this);
        // If timeout was reached, allow hide to occur
        if ($this.data("forceHidePopover")) {
            $this.data("forceHidePopover", false);
            return true;
        }
        // Prevent other `hide` handlers from executing
        e.stopImmediatePropagation();
        // Reset timeout checker
        clearTimeout($this.data("popoverTO"));
        // No longer hovering popover
        $this.data("hoveringPopover", false);
        // Flag for `show` event
        $this.data("waitingForPopoverTO", true);
        // In 1500ms, check to see if the popover is still not being hovered
        $this.data("popoverTO", setTimeout(function () {
            // If not being hovered, force the hide
            if (!$this.data("hoveringPopover")) {
                $this.data("forceHidePopover", true);
                $this.data("waitingForPopoverTO", false);
                $this.popover("hide");
            }
        }, 1500));
        // Stop default behavior
        return false;
    }
	}).on({
    show: function () {
        console.log("shown");
    },
    hide: function () {
        console.log("hidden");
    }
});

$('#voice').popover({
    html: true,
    trigger: 'hover',
    container: '#voice',
    placement: 'bottom',
    content: function () {
        return '<i class="icon-microphone"></i><div class="info"><h2>电话/语音</h2><p>您可以通过电话或其他语音设备语音控制您的设备</p></div>';
    },
    animation: false
	}).on({
    show: function (e) {
        var $this = $(this);
        // Currently hovering popover
        $this.data("hoveringPopover", true);
        // If it's still waiting to determine if it can be hovered, don't allow other handlers
        if ($this.data("waitingForPopoverTO")) {
            e.stopImmediatePropagation();
        }
    },
    hide: function (e) {
        var $this = $(this);
        // If timeout was reached, allow hide to occur
        if ($this.data("forceHidePopover")) {
            $this.data("forceHidePopover", false);
            return true;
        }
        // Prevent other `hide` handlers from executing
        e.stopImmediatePropagation();
        // Reset timeout checker
        clearTimeout($this.data("popoverTO"));
        // No longer hovering popover
        $this.data("hoveringPopover", false);
        // Flag for `show` event
        $this.data("waitingForPopoverTO", true);
        // In 1500ms, check to see if the popover is still not being hovered
        $this.data("popoverTO", setTimeout(function () {
            // If not being hovered, force the hide
            if (!$this.data("hoveringPopover")) {
                $this.data("forceHidePopover", true);
                $this.data("waitingForPopoverTO", false);
                $this.popover("hide");
            }
        }, 1500));
        // Stop default behavior
        return false;
    }
	}).on({
    show: function () {
        console.log("shown");
    },
    hide: function () {
        console.log("hidden");
    }
});

$('#tablet').popover({
    html: true,
    trigger: 'hover',
    container: '#tablet',
    placement: 'top',
    content: function () {
        return '<i class="icon-wrench"></i><div class="info"><h2>API</h2><p>您可以在您自己的应用系统中调用IoT开放的标准接口控制设备</p></div>';
    },
    animation: false
	}).on({
    show: function (e) {
        var $this = $(this);
        // Currently hovering popover
        $this.data("hoveringPopover", true);
        // If it's still waiting to determine if it can be hovered, don't allow other handlers
        if ($this.data("waitingForPopoverTO")) {
            e.stopImmediatePropagation();
        }
    },
    hide: function (e) {
        var $this = $(this);
        // If timeout was reached, allow hide to occur
        if ($this.data("forceHidePopover")) {
            $this.data("forceHidePopover", false);
            return true;
        }
        // Prevent other `hide` handlers from executing
        e.stopImmediatePropagation();
        // Reset timeout checker
        clearTimeout($this.data("popoverTO"));
        // No longer hovering popover
        $this.data("hoveringPopover", false);
        // Flag for `show` event
        $this.data("waitingForPopoverTO", true);
        // In 1500ms, check to see if the popover is still not being hovered
        $this.data("popoverTO", setTimeout(function () {
            // If not being hovered, force the hide
            if (!$this.data("hoveringPopover")) {
                $this.data("forceHidePopover", true);
                $this.data("waitingForPopoverTO", false);
                $this.popover("hide");
            }
        }, 1500));
        // Stop default behavior
        return false;
    }
	}).on({
    show: function () {
        console.log("shown");
    },
    hide: function () {
        console.log("hidden");
    }
});

$('#online').popover({
    html: true,
    trigger: 'hover',
    container: '#online',
    placement: 'top',
    content: function () {
        return '<i class="icon-globe"></i><div class="info"><h2>互联网 </h2><p>您可以通过其他互联网平台控制您的设备，比如微信</p></div>';
    },
    animation: false
	}).on({
    show: function (e) {
        var $this = $(this);
        // Currently hovering popover
        $this.data("hoveringPopover", true);
        // If it's still waiting to determine if it can be hovered, don't allow other handlers
        if ($this.data("waitingForPopoverTO")) {
            e.stopImmediatePropagation();
        }
    },
    hide: function (e) {
        var $this = $(this);
        // If timeout was reached, allow hide to occur
        if ($this.data("forceHidePopover")) {
            $this.data("forceHidePopover", false);
            return true;
        }
        // Prevent other `hide` handlers from executing
        e.stopImmediatePropagation();
        // Reset timeout checker
        clearTimeout($this.data("popoverTO"));
        // No longer hovering popover
        $this.data("hoveringPopover", false);
        // Flag for `show` event
        $this.data("waitingForPopoverTO", true);
        // In 1500ms, check to see if the popover is still not being hovered
        $this.data("popoverTO", setTimeout(function () {
            // If not being hovered, force the hide
            if (!$this.data("hoveringPopover")) {
                $this.data("forceHidePopover", true);
                $this.data("waitingForPopoverTO", false);
                $this.popover("hide");
            }
        }, 1500));
        // Stop default behavior
        return false;
    }
	}).on({
    show: function () {
        console.log("shown");
    },
    hide: function () {
        console.log("hidden");
    }
});


$('#email').popover({
    html: true,
    trigger: 'hover',
    container: '#email',
    placement: 'top',
    content: function () {
        return '<i class="icon-envelope"></i><div class="info"><h2>电子邮件</h2><p>IoT为您的提供专用的邮箱地址，您的用户可以通过电子邮件控制您的设备</p></div>';
    },
    animation: false
	}).on({
    show: function (e) {
        var $this = $(this);
        // Currently hovering popover
        $this.data("hoveringPopover", true);
        // If it's still waiting to determine if it can be hovered, don't allow other handlers
        if ($this.data("waitingForPopoverTO")) {
            e.stopImmediatePropagation();
        }
    },
    hide: function (e) {
        var $this = $(this);
        // If timeout was reached, allow hide to occur
        if ($this.data("forceHidePopover")) {
            $this.data("forceHidePopover", false);
            return true;
        }
        // Prevent other `hide` handlers from executing
        e.stopImmediatePropagation();
        // Reset timeout checker
        clearTimeout($this.data("popoverTO"));
        // No longer hovering popover
        $this.data("hoveringPopover", false);
        // Flag for `show` event
        $this.data("waitingForPopoverTO", true);
        // In 1500ms, check to see if the popover is still not being hovered
        $this.data("popoverTO", setTimeout(function () {
            // If not being hovered, force the hide
            if (!$this.data("hoveringPopover")) {
                $this.data("forceHidePopover", true);
                $this.data("waitingForPopoverTO", false);
                $this.popover("hide");
            }
        }, 1500));
        // Stop default behavior
        return false;
    }
	}).on({
    show: function () {
        console.log("shown");
    },
    hide: function () {
        console.log("hidden");
    }
});


$('#web').popover({
    html: true,
    trigger: 'hover',
    container: '#web',
    placement: 'top',
    content: function () {
        return '<i class="icon-laptop"></i><div class="info"><h2>网站</h2><p>您可以通过PC浏览器访问IoT站点，控制您的设备</p></div>';
    },
    animation: false
	}).on({
    show: function (e) {
        var $this = $(this);
        // Currently hovering popover
        $this.data("hoveringPopover", true);
        // If it's still waiting to determine if it can be hovered, don't allow other handlers
        if ($this.data("waitingForPopoverTO")) {
            e.stopImmediatePropagation();
        }
    },
    hide: function (e) {
        var $this = $(this);
        // If timeout was reached, allow hide to occur
        if ($this.data("forceHidePopover")) {
            $this.data("forceHidePopover", false);
            return true;
        }
        // Prevent other `hide` handlers from executing
        e.stopImmediatePropagation();
        // Reset timeout checker
        clearTimeout($this.data("popoverTO"));
        // No longer hovering popover
        $this.data("hoveringPopover", false);
        // Flag for `show` event
        $this.data("waitingForPopoverTO", true);
        // In 1500ms, check to see if the popover is still not being hovered
        $this.data("popoverTO", setTimeout(function () {
            // If not being hovered, force the hide
            if (!$this.data("hoveringPopover")) {
                $this.data("forceHidePopover", true);
                $this.data("waitingForPopoverTO", false);
                $this.popover("hide");
            }
        }, 1500));
        // Stop default behavior
        return false;
    }
	}).on({
    show: function () {
        console.log("shown");
    },
    hide: function () {
        console.log("hidden");
    }
});


$('#api').popover({
    html: true,
    trigger: 'hover',
    container: '#api',
    placement: 'top',
    content: function () {
        return '<i class="icon-rss"></i><div class="info"><h2>RSS</h2><p>您可以订阅设备服务，IoT将为您推送通知和设备最新的状态</p></div>';
    },
    animation: false
	}).on({
    show: function (e) {
        var $this = $(this);
        // Currently hovering popover
        $this.data("hoveringPopover", true);
        // If it's still waiting to determine if it can be hovered, don't allow other handlers
        if ($this.data("waitingForPopoverTO")) {
            e.stopImmediatePropagation();
        }
    },
    hide: function (e) {
        var $this = $(this);
        // If timeout was reached, allow hide to occur
        if ($this.data("forceHidePopover")) {
            $this.data("forceHidePopover", false);
            return true;
        }
        // Prevent other `hide` handlers from executing
        e.stopImmediatePropagation();
        // Reset timeout checker
        clearTimeout($this.data("popoverTO"));
        // No longer hovering popover
        $this.data("hoveringPopover", false);
        // Flag for `show` event
        $this.data("waitingForPopoverTO", true);
        // In 1500ms, check to see if the popover is still not being hovered
        $this.data("popoverTO", setTimeout(function () {
            // If not being hovered, force the hide
            if (!$this.data("hoveringPopover")) {
                $this.data("forceHidePopover", true);
                $this.data("waitingForPopoverTO", false);
                $this.popover("hide");
            }
        }, 1500));
        // Stop default behavior
        return false;
    }
	}).on({
    show: function () {
        console.log("shown");
    },
    hide: function () {
        console.log("hidden");
    }
});

$('#US').popover({
    html: true,
    trigger: 'hover',
    container: '#US',
    placement: 'top',
    content: function () {
        return '<div class="contactPopup"><h2>Miami</h2><p>+ 1(305) 722 5817<br>2701 South Bayshore Dr.<br>#303 Miami Florida, 33133</p></div>';
    },
    animation: false
	}).on({
    show: function (e) {
        var $this = $(this);
        // Currently hovering popover
        $this.data("hoveringPopover", true);
        // If it's still waiting to determine if it can be hovered, don't allow other handlers
        if ($this.data("waitingForPopoverTO")) {
            e.stopImmediatePropagation();
        }
    },
    hide: function (e) {
        var $this = $(this);
        // If timeout was reached, allow hide to occur
        if ($this.data("forceHidePopover")) {
            $this.data("forceHidePopover", false);
            return true;
        }
        // Prevent other `hide` handlers from executing
        e.stopImmediatePropagation();
        // Reset timeout checker
        clearTimeout($this.data("popoverTO"));
        // No longer hovering popover
        $this.data("hoveringPopover", false);
        // Flag for `show` event
        $this.data("waitingForPopoverTO", true);
        // In 1500ms, check to see if the popover is still not being hovered
        $this.data("popoverTO", setTimeout(function () {
            // If not being hovered, force the hide
            if (!$this.data("hoveringPopover")) {
                $this.data("forceHidePopover", true);
                $this.data("waitingForPopoverTO", false);
                $this.popover("hide");
            }
        }, 1500));
        // Stop default behavior
        return false;
    }
	}).on({
    show: function () {
        console.log("shown");
    },
    hide: function () {
        console.log("hidden");
    }
});

$('#SG').popover({
    html: true,
    trigger: 'hover',
    container: '#SG',
    placement: 'top',
    content: function () {
        return '<div class="contactPopup"><h2>Singapore</h2><p>+ 65(31)581497<br>67 Ayer Rajah <br>Crescent Unit 03-20/22<br>Singapore 139950</p></div>';
		
		
    },
    animation: false
	}).on({
    show: function (e) {
        var $this = $(this);
        // Currently hovering popover
        $this.data("hoveringPopover", true);
        // If it's still waiting to determine if it can be hovered, don't allow other handlers
        if ($this.data("waitingForPopoverTO")) {
            e.stopImmediatePropagation();
        }
    },
    hide: function (e) {
        var $this = $(this);
        // If timeout was reached, allow hide to occur
        if ($this.data("forceHidePopover")) {
            $this.data("forceHidePopover", false);
            return true;
        }
        // Prevent other `hide` handlers from executing
        e.stopImmediatePropagation();
        // Reset timeout checker
        clearTimeout($this.data("popoverTO"));
        // No longer hovering popover
        $this.data("hoveringPopover", false);
        // Flag for `show` event
        $this.data("waitingForPopoverTO", true);
        // In 1500ms, check to see if the popover is still not being hovered
        $this.data("popoverTO", setTimeout(function () {
            // If not being hovered, force the hide
            if (!$this.data("hoveringPopover")) {
                $this.data("forceHidePopover", true);
                $this.data("waitingForPopoverTO", false);
                $this.popover("hide");
            }
        }, 1500));
        // Stop default behavior
        return false;
    }
	}).on({
    show: function () {
        console.log("shown");
    },
    hide: function () {
        console.log("hidden");
    }
});


$('#TX').popover({
    html: true,
    trigger: 'hover',
    container: '#TX',
    placement: 'top',
    content: function () {
        return '<div class="contactPopup"><h2>Austin, TX</h2><p>+1 512 8611 924<br>9111 Old Jollyville Road, Suite 100<br> Austin, TX 78759</p></div>';
		
		
    },
    animation: false
	}).on({
    show: function (e) {
        var $this = $(this);
        // Currently hovering popover
        $this.data("hoveringPopover", true);
        // If it's still waiting to determine if it can be hovered, don't allow other handlers
        if ($this.data("waitingForPopoverTO")) {
            e.stopImmediatePropagation();
        }
    },
    hide: function (e) {
        var $this = $(this);
        // If timeout was reached, allow hide to occur
        if ($this.data("forceHidePopover")) {
            $this.data("forceHidePopover", false);
            return true;
        }
        // Prevent other `hide` handlers from executing
        e.stopImmediatePropagation();
        // Reset timeout checker
        clearTimeout($this.data("popoverTO"));
        // No longer hovering popover
        $this.data("hoveringPopover", false);
        // Flag for `show` event
        $this.data("waitingForPopoverTO", true);
        // In 1500ms, check to see if the popover is still not being hovered
        $this.data("popoverTO", setTimeout(function () {
            // If not being hovered, force the hide
            if (!$this.data("hoveringPopover")) {
                $this.data("forceHidePopover", true);
                $this.data("waitingForPopoverTO", false);
                $this.popover("hide");
            }
        }, 1500));
        // Stop default behavior
        return false;
    }
	}).on({
    show: function () {
        console.log("shown");
    },
    hide: function () {
        console.log("hidden");
    }
});




	$('body').scrollspy({ target: '.navspy' })
	
	$(window).load(function(){
    $('.bwWrapper').BlackAndWhite({
        hoverEffect : true, // default true
        // set the path to BnWWorker.js for a superfast implementation
        webworkerPath : false,
        // for the images with a fluid width and height 
        responsive:true,
        // this option works only on the modern browsers ( on IE lower than 9 it remains always 1)
        intensity:1,
        speed: { //this property could also be just speed: value for both fadeIn and fadeOut
            fadeIn: 200, // 200ms for fadeIn animations
            fadeOut: 800 // 800ms for fadeOut animations
        }
    });
});
