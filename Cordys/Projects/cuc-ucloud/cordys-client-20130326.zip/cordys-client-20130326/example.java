import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import com.cordys.facade.CORDYS;
import com.cordys.objects.CORDYS_TASK_INSTANCE;
import com.unicom.ucloud.workflow.exceptions.WFException;
import com.unicom.ucloud.workflow.filters.NotificationFilter;
import com.unicom.ucloud.workflow.filters.TaskFilter;
import com.unicom.ucloud.workflow.objects.ActivityDef;
import com.unicom.ucloud.workflow.objects.ActivityInstance;
import com.unicom.ucloud.workflow.objects.NotificationInstance;
import com.unicom.ucloud.workflow.objects.PageCondition;
import com.unicom.ucloud.workflow.objects.Participant;
import com.unicom.ucloud.workflow.objects.ProcessModel;
import com.unicom.ucloud.workflow.objects.ProcessModelParams;
import com.unicom.ucloud.workflow.objects.TaskInstance;

public class example {
	
	public static void main(String[] args) throws WFException{
		
		CORDYS cordys = new CORDYS("ucloud", "", "ucloud", "ucloud", "http://10.200.1.88:80");
		cordys.enableDebug();
////		System.out.println(cordys.getSamlart());
		ProcessModelParams pmp = new ProcessModelParams();
		pmp.setParameter("BO_ID", "测试1");//设置业务数据
		pmp.setParameter("BO_NAME", "测试流程");//设置业务数据
		pmp.setParameter("EXT1", "1");
		pmp.setParameter("EXT2", "2");
		Participant participant = new Participant();
		participant.setParticipantType("1");
		participant.setParticipantID("ucloud;fyang");//设置流程中第一个活动的参与者
//		Participant participant1 = new Participant();
//		participant1.setParticipantType("1");
//		participant1.setParticipantID("fyang");//设置流程中第一个活动的参与者
		List<Participant> list = new ArrayList<Participant>();
		list.add(participant);
//		list.add(participant1);
		
//		cordys.getActivitDefLists("com/chinaunicom/ucloud/bpm/ResourceInspect/ResourceInspect-Dispatch");
//		List<ActivityDef> list = cordys.getActivitDefLists("com/chinaunicom/ucloud/bpm/ResourceInspect/ResourceInspect-Dispatch");
//		Iterator i = list.iterator();
//		while(i.hasNext()){
//			ActivityDef p = (ActivityDef)i.next();
//			System.out.println(p.getActivityID());
//			System.out.println(p.getActivityName());
//		}
//		
//		TaskFilter taskfilter = new TaskFilter();
//		PageCondition pc = new PageCondition();
//		pc.setBegin(0);
//		pc.setLength(10);
//		taskfilter.setPageCondition(pc);
//		List<TaskInstance> task_inst_list = cordys.getMyWaitingTasks(taskfilter);
//		System.out.println(task_inst_list.size());
		
//		System.out.println(ti.getProcessMessage().getParameter("BO_ID"));
//		TaskFilter taskfilter = new TaskFilter();
//		taskfilter.setAppID("");
//		taskfilter.setJobTitle("");
//		PageCondition p = new PageCondition();
//		p.setBegin(0);
//		p.setLength(1);
//		taskfilter.setPageCondition(p);
//		List<TaskInstance> l = cordys.getMyWaitingTasks(taskfilter);
//		System.out.println(l.size());
//		cordys.backActivity("", "005056b9-0cc2-11e2-ed52-8b8a334f5d15");
//		cordys.terminateProcessInstance("000c2962-b6ed-11e2-ecd7-e1d3c06c9659");
		/*
		//查询待办任务
		TaskFilter taskfilter = new TaskFilter();
		taskfilter.setJobTitle("关于***");//设置查询条件
		List<TaskInstance> task_inst_list = cordys.getMyWaitingTasks(taskfilter);
		
		//获取单个任务的详细信息
		TaskInstance task_inst = cordys.getTaskInstanceObject(task_inst_list.iterator().next().getTaskInstID());		
		
		
		//查询待阅通知
		NotificationFilter notificationfilter = new NotificationFilter();
		notificationfilter.setJobTitle("关于***");
		List<NotificationInstance> notification_inst_list =  cordys.getMyUnreadNotifications(notificationfilter);
		
		//更新待阅为已阅
		NotificationInstance notificationinst = notification_inst_list.iterator().next();
		cordys.setNotificationToRead(notificationinst.getNotificationInstID());
		
		//认领任务
		cordys.claimTask(task_inst.getTaskInstID());
		
		//取消认领
		cordys.revokeClaimTask(task_inst.getTaskInstID());
		
		//暂停/挂起流程
		cordys.suspendProcessInstance(process_instance_id);
		
		//获取流程实例流转过的活动
		List<ActivityInstance> activity_inst_list = cordys.getActivityInstances(process_instance_id);
		*/
		
	}
	
}
